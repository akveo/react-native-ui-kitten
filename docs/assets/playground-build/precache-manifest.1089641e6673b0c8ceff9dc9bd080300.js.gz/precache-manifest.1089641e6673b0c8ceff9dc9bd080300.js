self.__precacheManifest = [
  {
    "revision": "c4958c976ce95cc875a0",
    "url": "static/js/app.20fd6ebf.chunk.js"
  },
  {
    "revision": "4260880e3f171f360824",
    "url": "static/js/runtime~app.3fc7848a.js"
  },
  {
    "revision": "f1acec7c07b084a182e8",
    "url": "static/js/2.ff287b01.chunk.js"
  },
  {
    "revision": "a78e4b51bf5dd2e05c7453e1b5194d45",
    "url": "static/media/brand-logo.a78e4b51.png"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "./fonts/AntDesign.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "./fonts/Entypo.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "./fonts/Feather.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "./fonts/FontAwesome.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "./fonts/Foundation.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "./fonts/Ionicons.ttf"
  },
  {
    "revision": "5a293a273bee8d740a045d9922b9a9ae",
    "url": "./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "6165c9d7a2e729ba57b23dd93add5366",
    "url": "static/media/back-icon-mask.6165c9d7.png"
  },
  {
    "revision": "872545dde71de3842234bf6afe80c4cb",
    "url": "./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "c6aef942e3668158ec29d4adcb2e768f",
    "url": "./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "3ed9575dcc488c3e3a5bd66620bdf5a4",
    "url": "./fonts/opensans-regular.ttf"
  },
  {
    "revision": "11eabca2251325cfc5589c9c6fb57b46",
    "url": "./fonts/roboto-regular.ttf"
  },
  {
    "revision": "4b06b5318598a23018740de25028e693",
    "url": "static/media/splash.4b06b531.png"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "serve.json"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "favicon.ico"
  },
  {
    "revision": "5e695e96a003a79f7f97060bf49409a9",
    "url": "expo-service-worker.js"
  },
  {
    "revision": "a443898b2c82a604350cf5df55a48585",
    "url": "manifest.json"
  },
  {
    "revision": "73431f41f7586e5a36439e84f4d25db5",
    "url": "index.html"
  }
];